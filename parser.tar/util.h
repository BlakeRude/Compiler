#ifndef _UTIL_H_
#define _UTIL_H_
void printTree(TreeNode*);
void printExtendedTree(TreeNode*);
bool isEqual(TreeNode*, TreeNode*);
void printHelp();
TreeNode* buildIOTree();
#endif